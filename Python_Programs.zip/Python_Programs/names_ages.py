#write a program to find all names and age of given string where string is "Python is 27 years olds and Java is 24 years old and Angular is 15 years old and c is 90 years old, where Anaconda is Python library, find all names and age of given string"
import re
s="Python is 27 years olds and Java is 24 years old and Angular is 15 years old and C is 90 years old, where Anaconda is Python library, find all names and age of given string"
#st=re.search(r'[A-Z]{1}(\w+)\S',string)
#print(st.group)

names=re.findall(r'[A-Z][a-z]* ',s)
ages=re.findall(r'\d+',s)
print(names,ages)
