l=[]
for i in range(2000,5001):
    a=str(i)
    if int(a[0])%2 == 0 and int(a[1])%2 == 0 and int(a[2])%2 == 0 and int(a[3])%2 == 0 :
        l.append(i)
print(l)
