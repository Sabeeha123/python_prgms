n=int(input("Enter the number:"))
if n%2 == 0:
    print("Wierd")
else:
    print("Not Wierd")
