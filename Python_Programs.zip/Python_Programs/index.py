def repetition(st,rno):
    s=""
    for i in st:
        s=s+i*rno
    return s
print(repetition(input("enter the string:"), int(input("enter no. of repetition:"))))
