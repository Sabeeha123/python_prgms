while True print('hello world')
