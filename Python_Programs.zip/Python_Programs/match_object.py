import re
s="python anaconda pandas, analyst"
#match.group(group1,....)
m=re.match(r"(\w+) (\w+) (\w+)",s,re.I)
print(m.group(0))
print(m.group(1))
print(m.group(2))
print(m.group(1,2))

#match.groups(default=None)
print(m.groups())
m1=re.match(r"(\d+)\.?(\d+)","24.3563")
print(m1.groups())

#match.start(group)
#match.end(group)
email="snangare@shilpasys.com"
em=re.search(r'shilpasys',email)
print(email[:em.start()]+email[em.end():])


s1="Send an email from this@email.com to test@user.com 34 times"
sr=re.search(r'(\w+)(@)(\w+)(.com)',s1)
print(sr.group())
res=re.findall(r'\S+@\S+',s1)
print(res)

