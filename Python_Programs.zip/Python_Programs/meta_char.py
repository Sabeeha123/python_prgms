s="rabcd;wxy#efghieee@wpqr!completeee#world"
'''for i in s:
    s1=""
    if i==";" or i=="#" or i=="@" or i == "!":
        pass
    else:
        print(i.split())
'''

if s.isaplha():
    pass
else:
    print(i)
