def factorial(n):
    if n == 0:
        return 1
    else:
        return n * (n-1)
n=int(input("enter the number:"))
print("value is:")
#for i in range(n):
print(factorial(n))
