#user input as aaabbssa and output should be in the form of a3b2s2a1
input = input("Enter the input:")
count = 1
for i in range(1, len(input) + 1):
    if i == len(input):
        print(input[i - 1] +str(count))
        break
    elif input[i - 1] == input[i]:
            count += 1
    else:
            print(input[i - 1] +str(count),end="")
            count = 1
