'''def function(string):
    prev=""
    cur=""
    count=0
    for i in string:
        if i not in prev:
            prev=i
        if i == prev:
            count+=1
            prev.append(count)
print(function("AABB"))






'''

def compress(string):
    #string=list[string]
    mystr=[]
    last=string[0]
    count=1
    for x in range(1,len(string)):
        if string[x]==last:
            count+=1
        else:
            mystr.append(last)
            mystr.append(str(count))
            count=1
        mystr.append(last)
        mystr.append(str(count))
        return ''.join(mystr)
print(compress("AAABBC"))
