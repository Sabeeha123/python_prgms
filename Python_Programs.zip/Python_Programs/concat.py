#concatenation the strings and adding the numbers
l=[]
dig=0
s=["python","hello","welcome",5,8,"3",7,3,"9"]
for i in s:
    if type(i) == str:
        l.append(i)
    else:
        dig+=i
print("concantenate string is:",'#'.join(l))
print("sum is:",dig)
    
