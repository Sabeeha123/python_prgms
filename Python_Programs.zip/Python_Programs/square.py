s=[]
for i in range(1,21):
    s.append(i*i)
print(s)

'''import random
l=[]
for i in range(1,21):
    l.append(random.randint(20,80))
print(l)
#c=0
c=l[0]
for i in l:
    if i < c:
       c=i
print("Maximum is:",c)'''

'''
import random
l=input("Enter the string")
l.split()
s=""
for i in l:
    if len(i'''
