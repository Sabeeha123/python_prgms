s2=["Hello"]
s1=""
for i in s2:
    s1=s2.replace("H","#")
print(s1)
