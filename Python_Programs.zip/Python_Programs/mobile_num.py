'''import re
s=int(input("Enter the number:"))
m=re.findall(r"\+\d{2}\s?0?\d{10}",s)
print(m)'''

import re
for _ in range(int(input())):
    if re.match(r'^[+91][7-9]{1}[0-9]{9}',input()):
        print("YES")
    else:
        print("NO")
