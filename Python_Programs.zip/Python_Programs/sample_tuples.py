l=[]
for i in range(20,41):
    l.append((i,i*i))
print(l)
