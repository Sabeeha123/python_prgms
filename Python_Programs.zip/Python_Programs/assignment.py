#Check whether given number is valid mobile number or not(only Indian Numbers)
import re 
def isValid(s): 
    Pattern = re.compile(r'[+91]{1}[7-9]{1}[0-9]{9}') 
    return Pattern.match(s) 
s = (input("Enter the number:"))
if (isValid(s)):  
    print ("Valid Number")      
else : 
    print ("Invalid Number")  
