'''s=input("Enter the string:")
s1=s.replace("a","#")
print(s1)
'''

#def replace(s1,s2,c=None):

'''
s1=input("enter the string:")
s2=input("enetr the string to be replaced:")
def replace(s1,s2):
    print(string.replace(s1,s2))
'''

def replace_all(text, dic):
    for i, j in dic.iteritems():
        text = text.replace(i, j)
    return text
text=input("enter the string:")
