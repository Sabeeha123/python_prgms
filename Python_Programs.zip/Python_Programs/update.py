d={'id':[],'name':[],'age':[]}
for i in range(int(input("how many entries?"))):
    for j in d:
        if j=='id' or j=='age':
            d[j].append(int(input("enter {}".format(j))))
        else:
            d[j].append(input("enter {}".format(j)))
print(d)
    
