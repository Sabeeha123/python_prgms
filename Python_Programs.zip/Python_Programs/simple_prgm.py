for i in range(7):
    if i==3: break
    print(i)
