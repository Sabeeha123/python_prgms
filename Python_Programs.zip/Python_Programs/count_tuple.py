#count number of string using list
l=[]
s=input("enter the string:")
c=0
for i in s:
    if (i, s.count(i)) not in l:
        l.append((i,s.count(i)))
print(l)
