def foo(x):
    yield x+1
    yield x**2
    yield x*5
    yield x%3
    yield x+x
f=foo(12)
print(f)
print(next(f))
print(next(f))
print(next(f))
print(next(f))
print(next(f))
print(next(f))
