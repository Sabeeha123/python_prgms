def alphadig(a):
    d={'letter':0,'digit':0}
    for i in a:
        if i.isalpha():
            d['letter']+=1
        else:
            d['digit']+=1
    print(d)
print(alphadig(input("enter the string:")))
