#print 2D array
l=[]
x=int(input("enter the no. rows:"))
y=int(input("enter the no. of col:"))
for i in range(x):
    l1=[]
    for j in range(y):
        l1.append(i*j)
    l.append(l1)
print(l)
        
