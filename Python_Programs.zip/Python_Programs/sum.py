'''def SumFunction(number1, number2):
	return number1+number2

print (SumFunction(1,2)) '''

'''def sum(items):
    sum=0
    for i in items:
        sum+=i
    return sum
print(sum([1,2,3,4,5,6]))'''

p=[2,1,2,4,5,5,5,1,2,5]
s=0
for i in p:
    s+=i
print ( s )
