l=lambda n:"even" if n%2 == 0 else "odd"
