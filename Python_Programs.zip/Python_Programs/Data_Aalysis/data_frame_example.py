import numpy as np
import pandas as pd
d={'one':pd.Series([1,2,3], index=['a','b','c']),'two':pd.Series([11.,12,13,14,15],index=['a','b','c','d','e'])}
df=pd.DataFrame(d)
print(df)
df1=pd.DataFrame(d,index=['d','a','e'],columns=["one","two","three"])
print(df1)
