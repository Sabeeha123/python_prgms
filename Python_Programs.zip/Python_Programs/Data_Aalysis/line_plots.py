import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
a=np.linspace(0,10,100)
b=np.exp(-a)
plt.plot(a,b)
plt.show()
