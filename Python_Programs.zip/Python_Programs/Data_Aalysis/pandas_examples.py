import numpy as np
import pandas as pd
#when data is ndarray
s=pd.Series(np.random.randn(5),index=['a1','a2','a3','a4','a5'])
print(s)

#when data is dictionary
d={"Name" : 'Python' ,'type' : "programming" , 'flexible' : "yes" }
s1=pd.Series(d)
print(s1)

#when data scalar value(5)
s2=pd.Series(5, index=['a','b','c'])
print(s2.name)
s4=pd.Series(5)
print(s4)
#print(s2['a':'('])
s3=s2.rename("Something")
print(s3)
