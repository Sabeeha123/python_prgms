import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
data=pd.read_csv('countries.csv')
print(data.head())
#compare the population growth in us and india
ch=data[data.country == "China"]
ind=data[data.country == "India"]
plt.plot(ch.year, ch.population/10**6)
plt.plot(ind.year, ind.population/10**6)
plt.legend(["China","India"])
plt.xlabel("India")
plt.ylabel("China")
plt.show()
