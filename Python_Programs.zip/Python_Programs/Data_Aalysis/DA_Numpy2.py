from numpy.linalg import inv,solve
import numpy as np
#a=np.array([[4,5,2],[6,3,2],[8,9,3]])
'''print(a)
a1=a.transpose()
print(a1)
a2=inv(a)
print(a2)'''

#b=np.array([4,5,3])
#c=np.array([3,2,1])

'''a=np.zeros((3,4))
print(a)

b=np.empty((2,3))
print(b)
'''

a=np.arange(10,30,5)
print(a)

b=np.arange(0,2,0.3)
print(b)

n=np.linspace(0,2,9)
print(n)

#n1=np.linspace(0,2,20)
#print(n1)

n*=3
print(n)
