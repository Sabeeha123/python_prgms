import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.random import normal,rand
x=normal(size=200)
plt.hist(x,bins=30)

a=rand(200)
b=rand(200)
plt.scatter(a,b)
plt.show()
