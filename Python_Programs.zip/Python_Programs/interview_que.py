d={1:"Hello", True:"okay", 1.0: "bye"}
print(d)
