#array list Comprerhension
x=int(input())
y=int(input())
n=int(input())
l=[]
l=[[i,j] for i in range(x+1) for j in range(y+1) if ((i+j)!=n)]
print(l)
