#Semaphore using Locks
import threading,time
tL=threading.Lock()
def timer(name,delay,rep):
    print("Timer:"+name+" started\n")
    tL.acquire()
    print("Timer:"+name+" has acquired lock\n")
    while rep>0:
        time.sleep(delay)
        print(name+":"+str(time.ctime(time.time())))
        rep-=1
    print(name+" is releasing lock\n")
    tL.release()
    print(name+" is completed\n")

t1=threading.Thread(target=timer,args=("timer1",1,5))
t2=threading.Thread(target=timer,args=("timer2",2,6))

t1.start()
t2.start()
print("program executed Successfully\n")
