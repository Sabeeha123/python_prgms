def fun():
    print("fun() is in one.py")
print("top-level in one.py")
if __name__=="__main__":
    print("Run Directly")
else:
    print("Imported in Another Module")
