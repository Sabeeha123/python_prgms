import threading,time
def square(seq):
    for i in seq:
        time.sleep(2)
        print("squares:",i*i)

def cube(seq):
    for i in seq:
        time.sleep(2)
        print("cubes:",i**3)

l=[2,4,5,8]
t1=threading.Thread(target=square,args=(l,))
t2=threading.Thread(target=cube,args=(l,))

t1.start()
time.sleep(3)
t2.start()
time.sleep(3)

t1.join()
t2.join()
