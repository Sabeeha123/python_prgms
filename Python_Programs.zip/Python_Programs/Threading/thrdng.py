import threading,time
def foo():
    print("starting thread activity\n")
    time.sleep(3)
    print("exiting thread")
t=threading.Thread(target=foo)
t.start()
