import one
print("top-level in two.py")
one.fun()
if __name__=="__main__":
    print("run directly")
else:
    print("imported in another module")
