print("The __name__ is:", __name__)
if __name__=="__main__":
    print("This file is run directly")
else:
    print("This file is imported in another module")
