s=int(input("enter s value:"))
t=int(input("enter t value:"))
r=int(input("enter r value:"))
def simple_interest(s,t,r):
    si=s*t*r/100
    print(si)
print(simple_interest(s,t,r))
