s=input("enter a string:")
c=0
s1=s.split()
s2=" "
for i in s1:
    if len(i)>c:
        c+=1
        print(c)
print("Max length:", s2)
