'''l=[]
for i in range(0,5):
    s=[]
    s.append(i*i)
    l.append(s)
print(l)
'''
'''odd_squares = {x: x*x for x in range(11)}

# Output: {1: 1, 3: 9, 5: 25, 7: 49, 9: 81}
print(odd_squares)'''

'''n=int(input("Input a number "))
d = dict()

for x in range(1,n+1):
    d[x]=x*x

print(d)'''

'''l = []
for i in range(0,2):
    s = []
    for j in range(0,10):
        s.append((i,j))
    l.append(s)
print (l)'''


some_list = ['a', 'b', 'c', 'b', 'd', 'm', 'n', 'n']
dups = []
for value in some_list:
    if some_list.count(value)>1:
        if value not in dups:
            dups.append(value)
print(dups)
