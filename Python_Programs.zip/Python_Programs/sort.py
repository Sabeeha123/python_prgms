'''l1=[1,2,5,8,3,12]
l2=[5,8,7,9,5,2,15]
l=l1+l2
l.sort()
print(l)
'''

l1=[1,2,5,8,3,12]
l2=[5,8,7,9,5,2,15]
l=[]
for i in l1:
    for j in l2:
        i+j
    l.sort()
print(l)
