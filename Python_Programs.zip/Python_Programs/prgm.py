'''d={}
for i in range(0,21):
    d[i]=i**2
print(d)'''

'''t=(1,'hello',3)
t.count(1)

l=[1,2,3,2,3,4,5]
x=[]
for i in l:
    if i not in x:
        x.append(i)
print(x)
'''

s={1,2,3}
s.discard(3)
s.add(4)+
print(s)
