import re
import string
legal_string=string.ascii_lower9case+string.ascii_digit+"\n+$%%^&*()@#{}"
print("[%s]"%re.escape(legal_string))
