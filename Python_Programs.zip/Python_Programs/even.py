l=[]
l=["wierd"  for i in range(2,6) if i % 2 != 0 ]
print(l)
l1=[]
l1=["Not wierd"  for i in range(6,20) if i % 2 == 0 or i > 20 ]
print(l1)
