l=['abc','xyz','aba','1221',"alasaal","mam",'3333',"python","55"]
a=0
for i in l:
    if len(i)>2 :
        if i[0] == i[-1]:
            a+=1
print(i,a)
    
