'''n=int(input("enter the number:"))
if n % 2 != 0:
    print("weird")
else:
    if n >=2 and n<=5:
        print("Not Weird")
    elif n>=6 and n<=20:
        print("Weird")
    elif n>20:
        print("Not Weird")

def even_odd(n):
    if n % 2 != 0:
        print("weird")
    else:
        if n >=2 and n<=5:
               print("Not Weird")
        elif n>=6 and n<=20:
               print("Weird")
        elif n>20:
               print("Not Weird")

print(even_odd(int(input("Enter the number:"))))
'''

n = int(input())
check = {True: "Not Weird", False: "Weird"}

print(check[
        n%2==0 and (
            n in range(2,6) or 
            n > 20)
    ])
