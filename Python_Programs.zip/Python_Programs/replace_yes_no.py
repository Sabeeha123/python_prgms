import re
s="yes I said yes I will Yes"
sp=re.sub(r'yes|Yes',"No",s)
print(sp)
