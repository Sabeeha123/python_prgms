s="""Python is a high-level scripting language which can be used for a wide variety of text processing, system administration and internet-related tasks.
Unlike many similar languages, it’s core language is very small and easy to master, while allowing the addition of modules to perform a virtually limitless variety of tasks. Python is a true object-oriented language, and is available on a wide variety of platforms. There’s even a python interpreter written entirely in Java, further enhancing python’s position as an excellent solution for internet-based problems. """
f=open("largest1.txt","w")
f.writelines(s)
f.close()
f1=open("largest1.txt","r")
s1=""
c=0
for line in f1.readlines():
    for j in line.split():
        if len(j)>c:
            c=len(j)
            s1+=j
print("largest word is:",s1)
