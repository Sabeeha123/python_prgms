s="abc"
it=iter(s)
print(len(s))
#print(len(it)) #type error

print(s)
print(it)

print(next(it))
print(next(it))
print(next(it))
print(next(it))
