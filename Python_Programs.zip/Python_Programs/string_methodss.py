#isalnum() : returns True if the string is aplha numeric otherwise it returns False
s="hello123"
print(s.isalnum())

#isalpha() : returns True if the string is only alphabets, otherwise returns false
s1="python" #"python123"
print(s1.isalpha())

#isdigit() : return True if the given string is numbers, otherwise return False
s2="123" #"python"
print(s2.isdigit())

#isupper() : returns true if the string is uppercase,otherwise returns false
s3="HELLO" #"hello" 
print(s3.isupper())

#isspace() : returns true if the string is a white space,otherwise returns false
s4="hello everyone" #"hello"
print(s4.isspace())

#istitle(chars=None) : return true if the string of first character is in uppercase, otherwise return false
s5="Python Programming Language" #"hello everyone"
print(s5.istitle())

#lstrip(chars=None) : return a copy of the string with leading white space removed. If chars is given and it is not a None, it removes character in chars instead.
s6="    python"
s7="aaaaaaapython"
print(s6.lstrip())
print(s7.lstrip("a"))

#rstrip(chars=None) : return a copy of the string with trailing whitespace removed. If chars is given and it is not a None, it removes character in chars instead.
s8="python11          "
s9="python11aaaaaaaaaa"
print(s8.rstrip())
print(s9.rstrip("a"))

#strip(chars=None) : return a copy of the string with leading and trailing whitespace removed
s10="       python222       "
s11="aaaaaaaaaapython222aaaaaaaa"
print(s10.strip())
print(s11.strip("a"))

#split(sep=None,maxsplit=-1) : return list of the words in the string using sep as delimiter string
#sep= The delimiter according t split the string. None (the default value) means split according any whitespace, abd discards empty strings from the results.
#maxsplit= maximum number of the splits to do. -1 means no limit
s12="hello welcome to python programming World"
print(s12.split())
print(s12.split(maxsplit=2))

#join(iterable) : It concantenate any no. of strings
l=["Hello","Welcome","to","python","Programming","World"]
print(" ".join(l))

#replace(old,new,count=-1) : return a copy of the string with all occurances of substring old replaced by substring by new.
p="hello,whatsup how are you?"
print(p.replace("whatsup","everyone"))
