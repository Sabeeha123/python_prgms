import re
s="hello@admin!how#are*you#python%java work"
s1="Cats are smarter than Dogs"
s2="aassdfsfkfknfdddaaalllkkkiiilllccclllffr"
s3="cats and dogs"

#re.sub(pattern,repl,string,count=0,flag=0):
sp=re.sub(r'[\s@*%!#]'," ",s,2)
print(sp)

#re.match(pattern,string,flag=0)
m=re.match(r'Cat',s1)
print(m)

#re.search(pattern,string,flag=0)
m1=re.search(r'smarter',s1)
print(m1)

#re.finditer(pattern,strting,flag=0)
fi=re.finditer(r'[aeiou]',s2)
print(next(fi))
print(list(fi))

#re.fullmatch(pattern,string,flag=0)
fm=re.fullmatch(r'cats and dogs',s3)
print(fm)

#re.subn(pattern,repl,string,count=0,flag=0)
spn=re.subn(r'[\s@*%!#]'," ",s)
print(spn)

#re.split(pattern,string,maxsplit=0,flags=0)
splt=re.split(r'[\s@#%!*]',s)
print(splt)

#re.purge()
p=re.purge()
print(p)

#re.compile(pattern,flag=0)
com=re.compile(r'[aeiou]')
cm=com.match(s2)
print(s2)

'''#re.escape(pattern)
import string
ls=string_ascii_lowercase+string_ascii_digit+"\n!@#$%^&*{}"
print("[%s]"%re.escape(ls))'''

#re.escape(pattern)
q="python.exe"
print(re.escape(q))

#re.findall(pattern,string,flags=0)
w="asdfghjklpoiuytreqwacvbnzziiaa"
fa=re.findall(r'[aeiou]',w)
print(fa)
