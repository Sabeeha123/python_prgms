#print the values of string
s=input("enter string:")
for i in range(len(s)):
    print("%s:%d"%(s[i],i))
