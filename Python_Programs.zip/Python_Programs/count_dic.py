#calculating the number of digits and letters present in the string
d={'letter':0,'digits':0}
s=input("enter the string:")
for i in s:
    if i.isalpha():
        d['letter']+=1
    elif i.isdigit():
        d['digits']+=1
    else:
        pass
print(d)
