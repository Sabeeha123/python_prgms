#replacing 'r' with '#'
s="restart"
s2=s.replace("r","#")
print(s2)
