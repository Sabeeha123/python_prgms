def digit(string):
    sum=0
    for i in string:
        if i.isdigit() == True:
            sum+=int(i)
    return sum
print(digit(input("eneter string:")))

            
