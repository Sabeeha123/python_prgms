#print fizzbuzz,fizz and buzz for number divisible by both 7 and 5, divisible by on;y 7 and divisible by only 5
s=[]
for i in range(1,36):
    if i % 7 == 0 and i % 5 == 0:
        print("fizzbuzz")
        continue
    elif i % 7 == 0:
        print("fizz")
        continue
    elif i %5 == 0:
        print("buzz")
        continue
    else:
        print(i)
        continue
        

