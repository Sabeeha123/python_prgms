#max,min,len of a string
s=input("Enter the string:")
print(max(s))
print(min(s))
print(len(s))
