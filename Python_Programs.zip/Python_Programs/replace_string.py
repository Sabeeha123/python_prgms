'''def replace(s1,s2,c=None):
    s2=s1.replace(s2,'#',3)
    print(s2)
s1=input("enter the string:")
s2=input("enter the replaceable string:")
'''
'''
our_str = 'Hello World'
 
 
import string
 
new_str = string.replace(our_str, 'World', 'Jackson')
print(new_str)
 
new_str = string.replace(our_str, 'Hello', 'Hello,')
print(new_str)
 
our_str = 'Hello you, you and you!'
new_str = string.replace(our_str, 'you', 'me', 1)
print(new_str)
new_str = string.replace(our_str, 'you', 'me', 2)
print(new_str)
new_str = string.replace(our_str, 'you', 'me', 3)
print(new_str)
'''

l = input("enter the string:")

w = input("enter the string to be replaced:")

l=l.replace(w,'newword',1)
print(l)






























