#positional/Default Parameters
def add(a,b):
    return a+b
print(add(2,5))

'''def add(a,b):
    return a+b
print(add(2))'''

#keyworded Parameters
def add(a,b=5):
    return a+b
print(add(3,2))
print(add(3))

def add(a,b='anaconda'):
    return a+b
print(add('hello'))

#Arbitrary Position Parameters
def foo(*a):
    c=0
    for i in a:
        c+=i
    return c
t=10,20,30,40,50,
print(foo(*t))

#arbitrary keyworded parameters
def baz(**kwargs):
    for k,v in kwargs.items():
        print("key is {} and value is {}".format(k,v))
d={'a':10,'b':20,'c':30,'d':40}
baz(**d)    
