a=[10,20,30,10,20,50,500,55,10,20,50,54,51]
dub=set()
unique=[]
for i in a:
    if i not in dub:
        unique.append(i)
        dub.add(i)
print(dub)

'''def remove_dub(x):
    z=[x[0]]
    for i in range(1,len(x)):
        for j in range(0,i):
            if x[i] == x[j]:
                break
            else:
                z.append([i])
    return z
y=[1,2,3,4,5,6,7,8,9,5,2,2,21,3]
print(remove_dub())
'''
'''
s=input("enter the string:")
l=s.split()
print(l)
p=[]
for i in l:
    if i not in l:
        p.append(i)
l=p '''

'''l=[]
s=['dog','cat','parrot','dog']
for i in range(len(s)):
    if s[i] not in l:
        l.append(s[i])
    print(l)'''

'''a={}
d=[]
for i in a:
    if i not in a:
        a[i]=1
    else:
        if a[i]== 1:
            d.append(i)
        a[i] +=1
'''
































    
