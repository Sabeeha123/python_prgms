def num_finder(sq,k):
    sum=[]
    for i in sq:
        
        if sum == k:
            print(i)
sq=[11,7,2,58]
print(num_finder(sq,18))
