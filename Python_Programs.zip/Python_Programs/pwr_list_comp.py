l=["hi",1,12,5,'2',5,2,"bye"]
l2=[11,12,13]
l1=[i*i for i in l if type(i) == int]
print(l1)
