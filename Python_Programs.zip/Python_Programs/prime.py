def prime(n,div=None):
    if div is None:
        div = n-1
    while div >=2:
        if n % div == 0:
            print("number not prime")
            return False
        else:
            return check(m, div-1)
            print("number is prime")
            return True
print(prime("enter the number:"))
