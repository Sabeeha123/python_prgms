import pickle
l=[10,20,30,15,21,36,50]
f=open("serialize.pkl","wb")
pickle.dump(l,f)
f.close()

f1=open("serialize.pkl","rb")
p=pickle.load(f1)
print(p)

pkl_obj=pickle.dumps(l)
print(l)

pyt_obj=pickle.loads(pkl_obj)
print(pyt_obj)
