l=[]
l1=["Wierd" for i in range(51) if i % 2 != 0]
print(l1)
