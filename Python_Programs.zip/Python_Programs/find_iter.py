import re
s="raajeeoubwxyouiziabwxyzabciou"
f=re.finditer(r'[aeiou]',s)
print(next(f))
print(list(f))
print(next(f))
