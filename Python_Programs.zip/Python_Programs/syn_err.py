#syntax_error
try:
    exec("10==<10")
except SyntaxError as e:
    print("syntax error occured")

#stop_iteration
import sys
l=[1,2,3,4]
it=iter(l)
try:
    for i in range(5):
        print(next(it))
except StopIteration as e:
    print(e,"Error has occurred")
