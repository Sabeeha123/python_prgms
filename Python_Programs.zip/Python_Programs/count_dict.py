#count the string values and keys using dictionary
d={}
s=input("enter the string:")
for i in s:
    if i not in d:
        d[i]=1
    else:
        d[i]+=1
print(d)
