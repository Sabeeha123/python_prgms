string="abracadabra"
s1=list(string)
s1[5]='k'
string=''.join(s1)
print(string)

def mutate_string(string,position,character):
    s1=list(string)
    s1[position]= character
    string=''.join(s1)
    return string
print(mutate_string("abracadabra",5,'k'))
