'''def unique_list(l):
  x = []
  for a in l:
    if a not in x:
      x.append(a)
  return x

print(unique_list([1,2,3,3,3,3,4,5])) '''

l=[1,2,3,3,3,3,4,5]
x=[]
for i in l:
    if i not in x:
        x.append(i)
print(x)
