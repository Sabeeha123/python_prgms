#concantenating the dictionary with keys and values
d={}
s=input("enter the string:")
s1=s.split()
for i in s1:
    if i[0] not in d: 
        d[i[0]]=i
    else:
        d[i[0]]+=i
        
print(d)
