#Reverse of a String without using Stepping
s=input("Enter the string:")
s1=""
for i in s:
    s1=i+s1
print(s1)

#Using Stepping
#print(s[::-1])
