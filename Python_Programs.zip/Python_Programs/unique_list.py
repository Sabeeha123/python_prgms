def digit(string):
    sum=""
    for i in string:
        if i.isalpha() == True:
            sum+=i
    return sum
print(digit(input("eneter string:")))
