a1=[2,6,9,11,13,17]
a2=[3,6,7,10,13,18]
a3=[4,5,6,9,11,13]
a=[]
for i in a1:
    for j in a2:
        for k in a3:
            if i==j==k:
                print(k)
            else:
                pass
