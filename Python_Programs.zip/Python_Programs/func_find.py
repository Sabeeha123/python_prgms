import re
def foo():
    fa=re.findall(r'[[^def][a-zA-Z]]')
    print(fa)
