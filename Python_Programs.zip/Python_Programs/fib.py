n=int(input("Enter the number:"))
for i in range(n):
    s=0
    s=s+i
    print(s)
    
